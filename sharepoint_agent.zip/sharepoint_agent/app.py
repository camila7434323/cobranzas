import json
import threading

from flask import Flask, Response, jsonify, render_template, request, stream_with_context
from dotenv import load_dotenv

load_dotenv()

from agent import Agent
from indexer import Indexer

app = Flask(__name__)

_index_status = {"status": "idle", "message": "Sin indexar", "count": 0}
_index_lock = threading.Lock()


def _run_indexing():
    global _index_status
    with _index_lock:
        _index_status = {"status": "running", "message": "Iniciando indexación...", "count": 0}

    def on_progress(msg):
        with _index_lock:
            _index_status["message"] = msg

    try:
        indexer = Indexer()
        count = indexer.index_sharepoint(progress_callback=on_progress)
        with _index_lock:
            _index_status = {"status": "done", "message": f"Indexación completa", "count": count}
    except Exception as e:
        with _index_lock:
            _index_status = {"status": "error", "message": str(e), "count": 0}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/index", methods=["POST"])
def start_index():
    with _index_lock:
        if _index_status["status"] == "running":
            return jsonify({"ok": False, "message": "La indexación ya está en curso"}), 409
    thread = threading.Thread(target=_run_indexing, daemon=True)
    thread.start()
    return jsonify({"ok": True})


@app.route("/status")
def status():
    with _index_lock:
        return jsonify(_index_status)


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(force=True)
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"error": "Pregunta vacía"}), 400

    agent = Agent()

    def generate():
        try:
            for chunk in agent.ask(question):
                yield f"data: {json.dumps({'text': chunk})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        yield "data: [DONE]\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


if __name__ == "__main__":
    app.run(debug=True, port=5000)
