import io
import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

from gdrive import GoogleDriveClient


COLLECTION_NAME = "sharepoint_docs"
EMBED_MODEL = "all-MiniLM-L6-v2"


def extract_pdf(content: bytes) -> str:
    import pypdf
    reader = pypdf.PdfReader(io.BytesIO(content))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def extract_docx(content: bytes) -> str:
    from docx import Document
    doc = Document(io.BytesIO(content))
    return "\n".join(p.text for p in doc.paragraphs)


def extract_excel(content: bytes) -> str:
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    parts = []
    for sheet in wb.worksheets:
        parts.append(f"[Hoja: {sheet.title}]")
        for row in sheet.iter_rows(values_only=True):
            cells = [str(c) if c is not None else "" for c in row]
            line = "\t".join(cells).strip()
            if line:
                parts.append(line)
    return "\n".join(parts)


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> list[str]:
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = start + chunk_size
        chunks.append(" ".join(words[start:end]))
        start += chunk_size - overlap
    return [c for c in chunks if c.strip()]


class Indexer:
    def __init__(self):
        self._client = chromadb.PersistentClient(path="./chroma_db")
        self._ef = SentenceTransformerEmbeddingFunction(model_name=EMBED_MODEL)
        self._collection = self._client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=self._ef,
        )

    def index_sharepoint(self, progress_callback=None) -> int:
        sp = GoogleDriveClient()
        files = sp.list_documents()

        self._client.delete_collection(COLLECTION_NAME)
        self._collection = self._client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=self._ef,
        )

        total_chunks = 0
        for i, file_info in enumerate(files):
            name = file_info["name"]
            if progress_callback:
                progress_callback(f"Procesando {i+1}/{len(files)}: {name}")
            try:
                content = sp.download_file(file_info)
                ext = "." + name.rsplit(".", 1)[-1].lower()
                if ext == ".pdf":
                    text = extract_pdf(content)
                elif ext == ".docx":
                    text = extract_docx(content)
                elif ext in {".xlsx", ".xls"}:
                    text = extract_excel(content)
                else:
                    continue

                chunks = chunk_text(text)
                if not chunks:
                    continue

                batch_size = 100
                for b in range(0, len(chunks), batch_size):
                    batch = chunks[b : b + batch_size]
                    ids = [f"{file_info['id']}_{b+j}" for j in range(len(batch))]
                    metas = [{"source": name, "chunk": b + j} for j in range(len(batch))]
                    self._collection.add(documents=batch, ids=ids, metadatas=metas)
                total_chunks += len(chunks)
            except Exception as e:
                if progress_callback:
                    progress_callback(f"Error en {name}: {e}")

        return total_chunks

    def search(self, query: str, n_results: int = 5) -> list[dict]:
        results = self._collection.query(
            query_texts=[query],
            n_results=min(n_results, self._collection.count() or 1),
        )
        output = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            output.append({"text": doc, "source": meta.get("source", ""), "distance": dist})
        return output

    def count(self) -> int:
        return self._collection.count()
