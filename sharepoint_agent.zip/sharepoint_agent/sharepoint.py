import os
import msal
import requests


SUPPORTED_EXTENSIONS = {".docx", ".pdf", ".xlsx", ".xls"}


class SharePointClient:
    def __init__(self):
        self.tenant_id = os.getenv("SHAREPOINT_TENANT_ID")
        self.client_id = os.getenv("SHAREPOINT_CLIENT_ID")
        self.client_secret = os.getenv("SHAREPOINT_CLIENT_SECRET")
        self.site_url = os.getenv("SHAREPOINT_SITE_URL", "").rstrip("/")
        self._token: str | None = None

    def _get_token(self) -> str:
        authority = f"https://login.microsoftonline.com/{self.tenant_id}"
        app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=authority,
            client_credential=self.client_secret,
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise ValueError(
                f"Error de autenticación Azure AD: {result.get('error_description', result)}"
            )
        return result["access_token"]

    def _headers(self) -> dict:
        if not self._token:
            self._token = self._get_token()
        return {"Authorization": f"Bearer {self._token}", "Accept": "application/json"}

    def _get_site_id(self) -> str:
        url = self.site_url.replace("https://", "")
        parts = url.split("/", 1)
        hostname = parts[0]
        site_path = "/" + parts[1] if len(parts) > 1 else ""
        resp = requests.get(
            f"https://graph.microsoft.com/v1.0/sites/{hostname}:{site_path}",
            headers=self._headers(),
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["id"]

    def list_documents(self) -> list[dict]:
        """Devuelve todos los archivos soportados de las bibliotecas de documentos."""
        site_id = self._get_site_id()
        resp = requests.get(
            f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives",
            headers=self._headers(),
            timeout=30,
        )
        resp.raise_for_status()
        drives = resp.json().get("value", [])

        files = []
        for drive in drives:
            files.extend(self._list_drive_files(drive["id"]))
        return files

    def _list_drive_files(self, drive_id: str, folder_id: str = "root") -> list[dict]:
        url = f"https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{folder_id}/children"
        files = []
        while url:
            resp = requests.get(url, headers=self._headers(), timeout=30)
            resp.raise_for_status()
            data = resp.json()
            for item in data.get("value", []):
                if "folder" in item:
                    files.extend(self._list_drive_files(drive_id, item["id"]))
                elif "file" in item:
                    name = item["name"]
                    ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
                    if ext in SUPPORTED_EXTENSIONS:
                        files.append(
                            {
                                "id": item["id"],
                                "name": name,
                                "drive_id": drive_id,
                                "size": item.get("size", 0),
                                "modified": item.get("lastModifiedDateTime", ""),
                                "download_url": item.get(
                                    "@microsoft.graph.downloadUrl"
                                ),
                            }
                        )
            url = data.get("@odata.nextLink")
        return files

    def download_file(self, file_info: dict) -> bytes:
        url = file_info.get("download_url")
        if not url:
            drive_id = file_info["drive_id"]
            item_id = file_info["id"]
            meta = requests.get(
                f"https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{item_id}",
                headers=self._headers(),
                timeout=30,
            )
            meta.raise_for_status()
            url = meta.json().get("@microsoft.graph.downloadUrl")
        resp = requests.get(url, timeout=60)
        resp.raise_for_status()
        return resp.content
