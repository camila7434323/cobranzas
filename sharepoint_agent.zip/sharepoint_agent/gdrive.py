import io
import os

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]
SUPPORTED_MIMETYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
}
SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".xlsx", ".xls"}


def _get_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    return build("drive", "v3", credentials=creds)


class GoogleDriveClient:
    def __init__(self):
        self._service = _get_service()

    def list_documents(self) -> list[dict]:
        files = []
        page_token = None
        while True:
            resp = (
                self._service.files()
                .list(
                    q="trashed = false",
                    spaces="drive",
                    fields="nextPageToken, files(id, name, mimeType, size, modifiedTime)",
                    pageToken=page_token,
                    pageSize=200,
                )
                .execute()
            )
            for item in resp.get("files", []):
                name = item["name"]
                ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
                mime = item.get("mimeType", "")
                if ext in SUPPORTED_EXTENSIONS or mime in SUPPORTED_MIMETYPES:
                    files.append(
                        {
                            "id": item["id"],
                            "name": name,
                            "size": item.get("size", 0),
                            "modified": item.get("modifiedTime", ""),
                        }
                    )
            page_token = resp.get("nextPageToken")
            if not page_token:
                break
        return files

    def download_file(self, file_info: dict) -> bytes:
        request = self._service.files().get_media(fileId=file_info["id"])
        buf = io.BytesIO()
        downloader = MediaIoBaseDownload(buf, request)
        done = False
        while not done:
            _, done = downloader.next_chunk()
        return buf.getvalue()
