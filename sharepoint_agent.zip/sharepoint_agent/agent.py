import os
from typing import Generator

from groq import Groq

from indexer import Indexer


SYSTEM_PROMPT = """Eres un asistente experto que responde preguntas basándose exclusivamente en el contenido de los documentos proporcionados como contexto.

Reglas:
- Responde únicamente con información que esté en el contexto.
- Si la respuesta no está en el contexto, di claramente que no encontraste esa información en los documentos.
- Cita el nombre del documento fuente cuando sea relevante (por ejemplo: "Según [nombre del archivo]...").
- Responde en el mismo idioma en que se formula la pregunta.
- Sé claro, preciso y conciso."""


class Agent:
    def __init__(self):
        self._client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        self._indexer = Indexer()

    def ask(self, question: str) -> Generator[str, None, None]:
        chunks = self._indexer.search(question, n_results=5)

        if not chunks:
            yield "No hay documentos indexados. Por favor, primero indexa el SharePoint."
            return

        context_parts = []
        for c in chunks:
            context_parts.append(f"[Fuente: {c['source']}]\n{c['text']}")
        context = "\n\n---\n\n".join(context_parts)

        stream = self._client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            max_tokens=2048,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Contexto de los documentos:\n\n{context}\n\n---\n\nPregunta: {question}"},
            ],
            stream=True,
        )

        for chunk in stream:
            text = chunk.choices[0].delta.content
            if text:
                yield text
